package com.example.application.views.list;

public class BackGround 
{
    String bgColor;
    
    public BackGround()
    {
        bgColor = "red";
    }

    public void setBgColor(String bgc)
    {
        bgColor = bgc;
    }
}
