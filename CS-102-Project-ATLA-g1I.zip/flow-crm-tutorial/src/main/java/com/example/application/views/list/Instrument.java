package com.example.application.views.list;

public class Instrument 
{
    String name;

    public Instrument(String n)
    {
        this.name = n;
    }

    public String getInstrumentName()
    {
        return name;
    }

    // variables
    
}
