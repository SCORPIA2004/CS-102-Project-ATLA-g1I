package com.example.application.views.list;

import com.vaadin.flow.component.orderedlayout.HorizontalLayout;

public class Horizontal extends HorizontalLayout {
    
}
